import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Model {

	public Map<String, String> tradutor() throws IOException {

		Map<String, String> traducoes = new HashMap<>();
		Scanner s = new Scanner(new File("D:\\Programas brutos\\ECLIPSE WEB\\tradutor\\src\\main\\webapp\\WEB-INF\\lib\\traducoesWeb.txt"));

		while (s.hasNext()) {

			String linha = s.nextLine();
			String[] valores = linha.split("-");
			traducoes.put(valores[0], valores[1]);

		}
		return traducoes;

	}

}
