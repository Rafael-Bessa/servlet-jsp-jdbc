
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/Servlet")
public class ConverteTemperatura extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String temperaturaRequisicao = request.getParameter("temperatura");

		if (request.getParameter("transformacao").equalsIgnoreCase("cpf")) {

			double temperaturaNumero = Integer.parseInt(temperaturaRequisicao);
			double fahrenheit = ((temperaturaNumero * 9) / 5) + 32;

			PrintWriter out = response.getWriter();
			out.println("<html> <body> <h1> " + fahrenheit + " graus Fahrenheit</h1> </body> </html>");
		}

		else {

			double temperaturaNumero = Integer.parseInt(temperaturaRequisicao);
			double celsius = ((temperaturaNumero - 32) * 5) / 9;

			PrintWriter out = response.getWriter();
			out.println("<html> <body> <h1> " + celsius + " graus Celsius</h1> </body> </html>");
		}

	}

}
