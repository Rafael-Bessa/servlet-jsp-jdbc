import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

	public Connection recuperarConexao() {

		try {
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/coursera?user=root&password=Rafaelbessa1");
		} catch (SQLException e) {
			throw new RuntimeException("Algo deu errado na conexão com o banco de dados", e);
		}

	}

}
