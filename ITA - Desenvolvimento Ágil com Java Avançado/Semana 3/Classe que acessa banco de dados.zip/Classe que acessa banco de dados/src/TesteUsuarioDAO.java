import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TesteUsuarioDAO {
	
	JdbcDatabaseTester jdt;

	@BeforeEach
	void setUp() throws Exception {
		
		jdt = new JdbcDatabaseTester("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/coursera?user=root&password=Rafaelbessa1");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/inicio.xml"));
		jdt.onSetup();
	}

	@Test
	void inserirTest() throws Exception {
		Usuario u = new Usuario("testelogin", "teste@email.com", "testenome", "testesenha", 0);
		AcessoBancoDeDados acess = new AcessoBancoDeDados();
		acess.inserir(u);
		
		IDataSet currentDataset = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataset.getTable("usuarioteste");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataset = loader.load("/verifica.xml");
		ITable expectedTable = expectedDataset.getTable("usuarioteste");
		Assertion.assertEquals(expectedTable, currentTable);
	}

	@Test
	void adicionarPontosTest() throws Exception {
		AcessoBancoDeDados acess = new AcessoBancoDeDados();
		acess.adicionarPontos("Rafaelb", 10);
		
		IDataSet currentDataset = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataset.getTable("usuarioteste");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataset = loader.load("/adicionaPontos.xml");
		ITable expectedTable = expectedDataset.getTable("usuarioteste");
		Assertion.assertEquals(expectedTable, currentTable);
	}
	
	@Test
	void recuperarTest() throws Exception {
		AcessoBancoDeDados acess = new AcessoBancoDeDados();
		Usuario u = acess.recuperar("Rafaelb");
		
		assertEquals("Rafael", u.getNome());
		assertEquals("Rafael@email.com", u.getEmail());
		assertEquals("senha", u.getSenha());
		assertEquals(7, u.getPontos());			
	}
	
	@Test
	void rankingTest() throws Exception {
		
		Usuario u = new Usuario("testelogin", "teste@email.com", "testenome", "testesenha", 20);
		AcessoBancoDeDados acess = new AcessoBancoDeDados();
		acess.inserir(u);
		
		IDataSet currentDataset = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataset.getTable("usuarioteste");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataset = loader.load("/ranking.xml");
		ITable expectedTable = expectedDataset.getTable("usuarioteste");
		Assertion.assertEquals(expectedTable, currentTable);
		
		List<Usuario> lista = acess.ranking();
		assertEquals("testenome", lista.get(0).getNome());
		assertEquals("Rafael", lista.get(1).getNome());
		
		
	}
	
	
	
	
}
